from django.apps import AppConfig


class TagConfig(AppConfig):
    name = 'tag'
