from django.contrib import admin
from .models import Hjuser

# Register your models here.


class HjuserAdmin(admin.ModelAdmin):
    list_display = ('username', 'password')  # 튜플형태


admin.site.register(Hjuser, HjuserAdmin)
