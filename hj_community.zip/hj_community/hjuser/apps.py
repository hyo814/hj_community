from django.apps import AppConfig


class HjuserConfig(AppConfig):
    name = 'hjuser'
